// A script code it does nothing but its gidden nothing but user see A massive 3 lines code
console.log("This script does nothing but it's hidden from the user");
// A style
// styles.css
// A script
// scripts.js